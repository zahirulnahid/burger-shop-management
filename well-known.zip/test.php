<html>
<head>
</head>    
<body>

<a href="my.bluetoothprint.scheme://https://cse.amartable.com/test/response.php">webpage print</a>
</body>
</html>
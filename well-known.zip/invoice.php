<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order']) && isset($_POST['totalAmount'])) {
    $order = json_decode($_POST['order'], true);
    $totalAmount = htmlspecialchars($_POST['totalAmount']);
} else {
    die("Invalid access.");
}

// Database connection
$servername = "localhost";
$username = "amartabl_coachin";
$password = "Bangladesh@1971";
$database = "amartabl_gourmet_burgers";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert into `orders` table
$stmt = $conn->prepare("INSERT INTO orders (total_amount) VALUES (?)");
if (!$stmt) {
    die("Database error: " . $conn->error);
}
$stmt->bind_param("d", $totalAmount);
$stmt->execute();
$order_id = $stmt->insert_id;
$stmt->close();

// Insert items into `order_items` table
$stmt = $conn->prepare("INSERT INTO order_items (order_id, name, quantity, price, total) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Database error: " . $conn->error);
}
foreach ($order as $item) {
    $name = htmlspecialchars($item['name']);
    $quantity = (int)$item['quantity'];
    $price = (float)$item['price'];
    $total = $quantity * $price;
    $stmt->bind_param("isidd", $order_id, $name, $quantity, $price, $total);
    $stmt->execute();
}
$stmt->close();

// Fetch saved data to display
$sql = "SELECT * FROM order_items WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();

// Bind the result to variables
$stmt->bind_result($item_id, $order_id, $name, $quantity, $price, $total);

// Fetch the results into an array
$items = [];
while ($stmt->fetch()) {
    $items[] = [
        'item_id' => $item_id,
        'order_id' => $order_id,
        'name' => $name,
        'quantity' => $quantity,
        'price' => $price,
        'total' => $total
    ];
}

$stmt->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #ffa401;
            color: white;
        }
        .total {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: right;
            margin-top: 20px;
        }
        button {
            background-color: blue;
            border: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: darkblue;
        }
        .sms-form {
            text-align: center;
            margin-top: 20px;
        }
        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            width: 300px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h1>Invoice</h1>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price (৳)</th>
                <th>Total (৳)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td><?php echo number_format($item['price'], 2); ?></td>
                    <td><?php echo number_format($item['total'], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="total">Total Amount: ৳ <?php echo number_format($totalAmount, 2); ?></div>
    
    <!-- Print Button -->
    <center>
        <form method="get" action="my.bluetoothprint.scheme://https://gourmetburgers.amartable.com/response.php">
            <button type="submit" name="invoiceID" value="<?php echo $order_id; ?>">Print Receipt</button>
        </form>
    </center>
    
    <!-- Send SMS Button -->
    <div class="sms-form">
        <input type="text" id="mobileNumber" placeholder="Enter Mobile Number" required>
        <button id="sendSmsBtn">Send SMS Invoice</button>
    </div>

    <script>
document.getElementById('sendSmsBtn').addEventListener('click', function () {
    const mobileNumber = document.getElementById('mobileNumber').value.trim();
    if (!mobileNumber || !/^\d{10,15}$/.test(mobileNumber)) {
        alert('Please enter a valid mobile number!');
        return;
    }
    const invoiceLink = `https://gourmetburgers.amartable.com/recipt.php?invoiceID=<?php echo $order_id; ?>`;
    const url = "https://api.bdbulksms.net/api.php?json";
    const data = new FormData();
    data.set('token', '29820043381729363418be5f9e7d59aaf916c2868b3f2a85b41a'); // Replace with your token
    data.set('message', `Thank you from THE GOURMET BURGER Invoice link: ${invoiceLink}`);
    data.set('to', mobileNumber);
    
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.send(data);
    xhr.onload = function () {
        if (xhr.status === 200) {
            const responseText = this.responseText;
            if (responseText.includes("Ok: SMS Sent Successfully")) {
                alert("SMS sent successfully!");
            } else {
                alert("Failed to send SMS. Response: " + responseText);
            }
        } else {
            alert("An error occurred while sending the SMS.");
        }
    };
});


    </script>
</body>
</html>
